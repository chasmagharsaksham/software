<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CHASMAGHAR-Add Orders</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
img[alt="www.000webhost.com"]{
    display: none;
}
</style>

<body>


    <?php
    include "../partials/db.php";
    include "../partials/header.php";

    $modelName = 0;
    $resultJhola = 0;
    $resultBox = 0;
    $quantityBox = 0;
    $prePayment = 0;
    //Checking for post request
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = trim($_POST['name']);
        $address = trim($_POST['address']);
        $contact = trim($_POST['contact']);
        $contact2 = trim($_POST['contact2']);
        if($contact2 == NULL){
            $contact2=0;
        }
        $chasma = trim(strtolower($_POST['chasma']));
        $colour = trim(strtolower($_POST['colour']));
        $message = trim($_POST['message']);
        $GLOBALS['quantity'] = trim($_POST['quantity']);
        $deliveryCharge = trim($_POST['deliveryCharge']);
        $amount = trim($_POST['amount']);
        $prePayment = trim($_POST['prePayment']);
        if($prePayment == NULL){
            $prePayment=0;
        }
        $cod = $amount - $prePayment;
        // Checking if pre payment is grater than cod
        if ($prePayment > $amount) {
            echo '
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong> Error!!</strong> Pre payment is Greater than total amount.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>  ';
        } else {

            //checking quantity
            if ($quantity <= 0) {
                echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Quantity is less than one.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  ';
            } else {
                //Checking if product is in stock or not
                $sql = "SELECT * from `stock` WHERE modelName = '$chasma' AND colour='$colour'";
                $result = mysqli_query($con, $sql);
                $num = mysqli_num_rows($result);
                while ($row = mysqli_fetch_assoc($result)) {
                    $idStock = $row['id'];
                    $modelName = $row['modelName'];
                    $modelColour = $row['colour'];
                    $quantityStock = $row['quantity'];
                    $category = $row['category'];
                    
                }
                if ($modelName == $chasma && $modelColour == $colour) {

                    //Checking if the quanitity is available ot not
                    if ($quantity <= $quantityStock) {
                        if ($category == 'Box') {
                            //Quantity updated of product
                            $quantityStock = $quantityStock - $quantity;
                            $sqlStock = "UPDATE `stock` SET `quantity` = '$quantityStock' WHERE `stock`.`id` = $idStock";
                            $resultStock = mysqli_query($con, $sqlStock);
                            if ($resultStock) {
                                //adding to orders    
                                $sql = "INSERT INTO `orders` (`Name`, `Address`, `Contact`,`contact2`, `Product`, `Colour`, `Quantity`, `deliveryCharge`,  `Amount`,`COD`,`prePayment`, `Message`, `Stage`, `Dt`) VALUES ('$name', '$address', '$contact' , '$contact2' ,'$chasma',  '$colour', '$quantity', '$deliveryCharge','$amount','$cod', '$prePayment', '$message', 'Order created', current_timestamp())";
                                $result = mysqli_query($con, $sql);

                                if ($result) {
                                    echo '
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong> Success!!</strong> Order added.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div> ';
                                } else {
                                    echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Something went wrong.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  ';
                                }
                            }
                        }
                        //Checking category of product
                        if ($category == 'Sunglasses') {
                            //Checking box quantity
                            $sql = "SELECT * FROM `stock` WHERE category = 'Packing Box' AND modelName = 'Brown Box'";
                            $result = mysqli_query($con, $sql);
                            while ($row = mysqli_fetch_assoc($result)) {
                                $quantityBox = $row['quantity'];
                            }
                            if ($quantity <= $quantityBox) {

                                //update box
                                $quantityBox = $quantityBox - $quantity;
                                $sql = "UPDATE `stock` SET `quantity` = '$quantityBox' WHERE `stock`.`id` = 1";
                                $resultBox = mysqli_query($con, $sql);

                                //Quantity updated of product
                                $quantityStock = $quantityStock - $quantity;
                                $sqlStock = "UPDATE `stock` SET `quantity` = '$quantityStock' WHERE `stock`.`id` = $idStock";
                                $resultStock = mysqli_query($con, $sqlStock);



                                if ($resultBox  && $resultStock) {
                                    //adding to orders    
                                    $sql = "INSERT INTO `orders` (`Name`, `Address`, `Contact`,`contact2`, `Product`, `Colour`, `Quantity`, `deliveryCharge`,  `Amount`,`COD`,`prePayment`, `Message`, `Stage`, `Dt`) VALUES ('$name', '$address', '$contact',  '$contact2','$chasma',  '$colour', '$quantity', '$deliveryCharge','$amount','$cod', '$prePayment', '$message', 'Order created', current_timestamp())";
                                    $result = mysqli_query($con, $sql);

                                    if ($result) {
                                        echo '
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong> Success!!</strong> Order added.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div> ';
                                    } else {
                                        echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Something went wrong.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  ';
                                    }
                                }
                            } else {
                                echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Packing Box is Not enough.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  ';
                            }
                        } else if ($category == 'Specs') {
                            //Checking box quantity

                            $sql = "SELECT * FROM `stock` WHERE category = 'Packing Box' AND modelName = 'Specs Box'";
                            $result = mysqli_query($con, $sql);
                            while ($row = mysqli_fetch_assoc($result)) {
                                $quantityBox = $row['quantity'];
                            }
                            if ($quantity <= $quantityBox) {

                                // Update Box
                                $quantityBox = $quantityBox - $quantity;
                                $sql = "UPDATE `stock` SET `quantity` = '$quantityBox' WHERE `stock`.`id` = 2";
                                $resultBox = mysqli_query($con, $sql);


                                //Quantity updated of product
                                $quantityStock = $quantityStock - $quantity;
                                $sqlStock = "UPDATE `stock` SET `quantity` = '$quantityStock' WHERE `stock`.`id` = $idStock";
                                $resultStock = mysqli_query($con, $sqlStock);



                                if ($resultBox && $resultStock) {
                                    //adding to orders    
                                    //adding to orders    
                                    $sql = "INSERT INTO `orders` (`Name`, `Address`, `Contact`,`contact2`, `Product`, `Colour`, `Quantity`, `deliveryCharge`,  `Amount`,`COD`,`prePayment`, `Message`, `Stage`, `Dt`) VALUES ('$name', '$address', '$contact' , '$contact2', '$chasma',  '$colour', '$quantity', '$deliveryCharge','$amount','$cod', '$prePayment', '$message', 'Order created', current_timestamp())";
                                    $result = mysqli_query($con, $sql);

                                    if ($result) {
                                        echo '
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong> Success!!</strong> Order added.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div> ';
                                    } else {
                                        echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Something wnt wrong.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  ';
                                    }
                                }
                            } else {
                                echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Packing Box is Not enough.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  ';
                            }
                        }




                        // Product Quantity            
                    } else {


                        echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Only <b>' . $quantityStock . ' ' . $modelName . '</b> of <b>' . $modelColour . '</b> colour is available in stock..
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  ';
                    }

                    // Product On stock                
                } else {
                    echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Product not found on Sotck.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div> ';
                }

                //Post and pre payment
            }
        }
    }
    ?>
    <div class="container  text-center d-flex justify-content-between mt-5 margin-left-5">
        <form action="/orders/orders.php" action="POST">
            <button type="Submit" class="btn btn-success ">Orders</button>
        </form>
        <h2 class="pe-pd-3">Add Orders</h2>

        <form action="/orders/exportOrders.php" action="POST">
            <button type="Submit" class="btn btn-success ">Export Orders to Excel</button>
        </form>
    </div>
    <!-- form -->
    <div class="container py-5">
        <form action="/orders/add_orders.php" method="POST">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" aria-describedby="emailHelp" name="name" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Address</label>
                <input type="text" class="form-control" id="address" name="address" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Contact 1</label>
                <input type="text" class="form-control" id="contact" name="contact" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Contact 2</label>
                <input type="text" class="form-control" id="contact" name="contact2" placeholder="Optional"/>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Product</label>
                <input type="text" class="form-control" id="chasma" name="chasma" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Colour</label>
                <input type="text" class="form-control" id="colour" name="colour" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Quantity</label>
                <input type="text" class="form-control" id="quantity" name="quantity" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Delivery Charge</label>
                <input type="text" class="form-control" id="quantity" name="deliveryCharge" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Amount</label>
                <input type="text" class="form-control" id="amount" name="amount" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Pre-Payment</label>
                <input type="text" class="form-control" id="cod" name="prePayment" placeholder="Optional" />
            </div>
            <div class="form-floating">
                <textarea class="form-control my-4" placeholder="Leave a comment here" id="floatingTextarea2"
                    style="height: 100px" name="message"></textarea>
                <label for="floatingTextarea2">Comments</label>
            </div>

            <button type="submit" class="btn btn-outline-primary">Submit</button>
        </form>
    </div>
    <!-- form end -->




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>


</body>

</html>