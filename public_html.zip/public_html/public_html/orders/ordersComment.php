<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CHASMAGHAR-Order Comment</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
</head>
<style>
    a{
        text-decoration: none;
        color:black;
    }
</style>
<body>
    <?php
    include "../partials/db.php";
    include "../partials/header.php";
    $orderId = $_GET['id'];
    if (isset($_POST['comment'])) {
        $comment = $_POST['message'];
        $sql = "INSERT INTO `comments` (`comment`, `orderId`, `Dt`) VALUES ('$comment', '$orderId', current_timestamp())";
        $result = mysqli_query($con, $sql);
    }

    $sql = "SELECT * from orders WHERE id = $orderId";
    $result = mysqli_query($con, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $name = $row['Name'];
        $amount = $row['Amount'];
        $deliveryCharge = $row['deliveryCharge'];
    }

    if (isset($_POST['update'])) {
        $updateAmount = $_POST['updateAmount'];
        $charge = $_POST['charge'];
        $sql = "UPDATE `orders` SET `Amount` = '$updateAmount',`deliveryCharge` = '$charge' WHERE `orders`.`id` = $orderId";
        $result = mysqli_query($con, $sql);
        if ($result) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong> Success!!</strong> Order Updated Successfully,
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>  ';
            header('locaton: /orders/orders.php');
        } else {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong> Error!!</strong> Sorry an error occured.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>  ';
        }
    }

    ?>

    <div class="bg-body-secondary p-3 m-3">
        <h3 class="text-center m-5"><a href="/orders/orders.php">Edit Order</a></h3>



        <!-- form -->

        <form action="<?php echo '/orders/ordersComment.php?id=' . $orderId . '' ?>" method="POST">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input type="text" class="form-control" id="model" aria-describedby="emailHelp" name="name" value="<?php echo $name; ?>" disabled />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Amount</label>
                <input type="number" class="form-control" id="costPrice" name="updateAmount" value="<?php echo $amount; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Delivery Charge</label>
                <input type="number" class="form-control" id="costPrice" name="charge" value="<?php echo $deliveryCharge; ?>" />
            </div>

            <button type="submit" class="btn btn-outline-success my-2" name="update">Submit</button>
        </form>
    </div>
    <!-- form end -->
    <div class="bg-body-secondary p-3 m-3">
        <h3 class="text-center m-5">Add Comments</h3>
        <form class="form-floating " method="POST" action="<?php echo '/orders/ordersComment.php?id=' . $orderId . '' ?>">
            <div class="form-floating my-3">
                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px" name="message"></textarea>
                <label for="floatingTextarea2">Comments</label>
            </div>
            <button type="submit" class="btn btn-outline-success" name="comment">Submit</button>
        </form>
        <h3 class="text-center m-5">Comments</h3>
        <ul class="list-group bg-body-secondary">
            <li class="list-group-item d-flex justify-content-between">
                <div>Comment</div>
                <div>Date</div>
            </li>
            <?php

            $sql = "SELECT * from comments WHERE orderId = $orderId ORDER BY id DESC";
            $result = mysqli_query($con, $sql);
            $num = mysqli_num_rows($result);
            if ($num > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id'];
                    echo  '
                     
                    <li class="list-group-item d-flex justify-content-between"><div>' . $row['comment'] . '</div><div>' . $row['Dt'] . '</div></li>

                    ';
                }
            } else {
                echo '<li class="list-group-item ">No comments on this order</li>';
            }

            ?>
        </ul>
    </div>


    <script src=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>