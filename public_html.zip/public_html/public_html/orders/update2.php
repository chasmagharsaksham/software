<?php
    session_start();
    $_SESSION['update'] = true;
    include "../partials/db.php";


$stage =  $_GET['stage'];
$id = $_GET['id'];
$product = $_GET['product'];
$colour = $_GET['colour'];
$quantity = $_GET['quantity'];

if($stage == 'Returned'){
    $sql = "SELECT * FROM `stock` WHERE modelName = '$product' AND colour = '$colour'";
    $result = mysqli_query($con, $sql);
    while($row = mysqli_fetch_assoc($result)){
        $stockId = $row['id'];
        $stockQuantity = $row['quantity'];
        $stockCategory = $row['category'];
    }
    
    $stockQuantity += $quantity;
    $sql = "UPDATE `stock` SET `quantity` = '$stockQuantity' WHERE `stock`.`id` = $stockId";
    $result=mysqli_query($con, $sql);
    if($result){
       if($stockCategory == "Sunglasses"){
        
            $sql = "SELECT * FROM `stock` WHERE id= 1";
            $result = mysqli_query($con, $sql);
            while($row = mysqli_fetch_assoc($result)){
                $boxQuantity = $row['quantity'];
            }
            $boxQuantity += $quantity;
            $sql = "UPDATE `stock` SET `quantity` = '$boxQuantity' WHERE `stock`.`id` = 1";
            $result=mysqli_query($con, $sql);
            if($result){
            
        
            $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
        $result=mysqli_query($con, $sql);
        if($result){
            
        
            echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/index.php";
        </script>';
            
        }
        else{
        echo 
              "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
}
            
        }
       }
       else if($stockCategory == "Specs"){
             $sql = "SELECT * FROM `stock` WHERE id= 2";
            $result = mysqli_query($con, $sql);
            while($row = mysqli_fetch_assoc($result)){
                $boxQuantity = $row['quantity'];
            }
            $boxQuantity += $quantity;
            $sql = "UPDATE `stock` SET `quantity` = '$boxQuantity' WHERE `stock`.`id` = 2";
            $result=mysqli_query($con, $sql);
            if($result){
            
        
           $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
        $result=mysqli_query($con, $sql);
        if($result){
            
        
            echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/index.php";
        </script>';
            
        }
        else{
        echo 
              "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
}
            
        }
       }
       else{
             $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
        $result=mysqli_query($con, $sql);
        if($result){
            
        
            echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/index.php";
        </script>';
            
        }
        else{
        echo 
              "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
}
       }
       
    }
}

else{
     $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
        $result=mysqli_query($con, $sql);
        if($result){
            
            echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/index.php";
        </script>';
            
        }
        else{
        echo 
              "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
}
}

?>