<?php
include "../partials/db.php";

$stage =  $_GET['stage'];
$id = $_GET['id'];
$product = $_GET['product'];
$colour = $_GET['colour'];
$quantity = $_GET['quantity'];
$amount = $_GET['amount'];
$deliveryCharge = $_GET['deliveryCharge'];

if ($stage == 'Exchange') {
    if (isset($_POST['exchange'])) {
        $newModel = trim(strtolower($_POST['newModel']));
        $newColour = trim(strtolower($_POST['newColour']));
        $newAmount = trim(strtolower($_POST['amountNew']));
        $newLogistic = trim(strtolower($_POST['newLogistic']));
        $newQuantity = trim(strtolower($_POST['newQuantity']));
        $modelName = "";
        $sql = "SELECT * FROM `stock` WHERE modelName = '$newModel' AND colour = '$newColour'";
        $result = mysqli_query($con, $sql);
        $num = mysqli_num_rows($result);
        while ($row = mysqli_fetch_assoc($result)) {
            $idStock = $row['id'];
            $modelName = $row['modelName'];
            $modelColour = $row['colour'];
            $quantityStock = $row['quantity'];
            $category = $row['category'];
        }
        if ($modelName == $newModel && $modelColour == $newColour) {

            //Checking if the quanitity is available ot not
            if ($newQuantity <= $quantityStock) {

                //Quantity updated of product
                $quantityStock = $quantityStock - $newQuantity;
                $sqlStock = "UPDATE `stock` SET `quantity` = '$quantityStock' WHERE `stock`.`id` = $idStock";
                $resultStock = mysqli_query($con, $sqlStock);
                if ($resultStock) {
                    $sql = "SELECT * FROM `stock` WHERE modelName = '$product' AND colour = '$colour'";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                        $stockId = $row['id'];
                        $stockQuantity = $row['quantity'];
                    }

                    $stockQuantity += $quantity;
                    $sqlOld = "UPDATE `stock` SET `quantity` = '$stockQuantity' WHERE `stock`.`id` = $stockId";
                    $resultOld = mysqli_query($con, $sqlOld);
                    if ($resultOld) {
                        $sql = "UPDATE `orders` SET `Stage` = 'Exchange Order Created', `Quantity` = '$newQuantity',  `deliveryCharge` = '$newLogistic', Amount='$newAmount', `Product` = '$newModel', `Colour`='$newColour'  WHERE `orders`.`id` = $id";
                        $result = mysqli_query($con, $sql);
                        if ($result) {
                            echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/orders/orders.php";
        </script>';
                        } else {
                            echo
                            '
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong>Something Went Wrong
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  
                            ';
                        }
                    }
                }
            } else {

                echo
                '
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Only <b>' . $quantityStock . ' ' . $modelName . '</b> of <b>' . $modelColour . '</b> colour is available in stock..
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>  
                            ';
            }
        } else {
            echo '
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong> Error!!</strong> Product not found on Sotck.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div> ';
        }
    }
} else if ($stage == "Returned") {
    $sql = "SELECT * FROM `stock` WHERE modelName = '$product' AND colour = '$colour'";
    $result = mysqli_query($con, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $stockId = $row['id'];
        $stockQuantity = $row['quantity'];
        $stockCategory = $row['category'];
    }

    $stockQuantity += $quantity;
    $sql = "UPDATE `stock` SET `quantity` = '$stockQuantity' WHERE `stock`.`id` = $stockId";
    $result = mysqli_query($con, $sql);
    if ($result) {
        if ($stockCategory == "Sunglasses") {

            $sql = "SELECT * FROM `stock` WHERE id= 1";
            $result = mysqli_query($con, $sql);
            while ($row = mysqli_fetch_assoc($result)) {
                $boxQuantity = $row['quantity'];
            }
            $boxQuantity += $quantity;
            $sql = "UPDATE `stock` SET `quantity` = '$boxQuantity' WHERE `stock`.`id` = 1";
            $result = mysqli_query($con, $sql);
            if ($result) {


                $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
                $result = mysqli_query($con, $sql);
                if ($result) {


                    echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/orders/orders.php";
        </script>';
                } else {
                    echo
                    "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
                }
            }
        } else if ($stockCategory == "Specs") {
            $sql = "SELECT * FROM `stock` WHERE id= 2";
            $result = mysqli_query($con, $sql);
            while ($row = mysqli_fetch_assoc($result)) {
                $boxQuantity = $row['quantity'];
            }
            $boxQuantity += $quantity;
            $sql = "UPDATE `stock` SET `quantity` = '$boxQuantity' WHERE `stock`.`id` = 2";
            $result = mysqli_query($con, $sql);
            if ($result) {


                $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
                $result = mysqli_query($con, $sql);
                if ($result) {


                    echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/orders/orders.php";
        </script>';
                } else {
                    echo
                    "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
                }
            }
        } else {
            $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
            $result = mysqli_query($con, $sql);
            if ($result) {


                echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/orders/orders.php";
        </script>';
            } else {
                echo
                "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
            }
        }
    }
} else {
    $sql = "UPDATE `orders` SET `Stage` = '$stage' WHERE `orders`.`id` = $id";
    $result = mysqli_query($con, $sql);
    if ($result) {
        echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/orders/orders.php";
        </script>';
    } else {
        echo
        "
        <script>
        Swal.fire(

            'ERROR!!',
            'An Error Occured',
            'error'
            )
        </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHASMAGHAR-Exchange</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>

<body>
    <?php
    include "../partials/header.php";
    ?>
    <h2 class="text-center my-5">Exchange Order</h2>
    <?php
    if ($stage == "Exchange") {
        echo '
        <div class="m-5">
            <form method="POST" action="/orders/update.php?stage=' . $stage . '&id=' . $id . '&product=' . $product . '&colour=' . $colour . '&quantity=' . $quantity . '&amount=' . $amount . '&deliveryCharge=' . $deliveryCharge . '">
                <div class="mb-3 ">
                    <label for="exampleInputEmail1" class="form-label">Old Model Name</label>
                    <input  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="' . $product . '" disabled>
                </div>
                <div class="mb-3 ">
                    <label for="exampleInputEmail1" class="form-label">Old Model Colour</label>
                    <input  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="' . $colour . '" disabled>
                </div>
                <div class="mb-3 ">
                    <label for="exampleInputEmail1" class="form-label">Quantity</label>
                    <input  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="' . $quantity . '" name="newQuantity">
                </div>
                <div class="mb-3 ">
                    <label for="exampleInputEmail1" class="form-label">Logistics</label>
                    <input  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  value="' . $deliveryCharge . '"  name="newLogistic">
                </div>
                <div class="mb-3 ">
                    <label for="exampleInputEmail1" class="form-label">Amount</label>
                    <input  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  value="' . $amount . '"  name="amountNew">
                </div>
                <div class="mb-3 ">
                    <label for="exampleInputEmail1" class="form-label">New Model Name</label>
                    <input  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="newModel">
                </div>
                <div class="mb-3 ">
                    <label for="exampleInputEmail1" class="form-label">New Model Colour</label>
                    <input  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="newColour">
                </div>

                <button type="submit" class="btn btn-outline-dark" name="exchange">Submit</button>
            </form>
        </div>
  ';
    }
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>