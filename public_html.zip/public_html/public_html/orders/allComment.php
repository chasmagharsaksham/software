<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CHASMAGHAR-Order Comment</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
</head>
<style>
a {
    text-decoration: none;
    color: black;
}
</style>

<body>
    <?php
    include "../partials/db.php";
    include "../partials/header.php";
    ?>


    <div class="bg-body-secondary p-3 m-3">
        <h3 class="text-center m-5">Comments</h3>
        <ul class="list-group bg-body-secondary">
            <li class="list-group-item d-flex justify-content-between">
                <div>Comment</div>
                <div>Date</div>
            </li>
            <?php

            $date = date("Y-m-d");
            $sql = "SELECT * from comments WHERE Dt = '$date' ORDER BY id DESC";
            $result = mysqli_query($con, $sql);
            $num = mysqli_num_rows($result);
            if ($num > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id'];
                    echo  '
                     
                    <li class="list-group-item d-flex justify-content-between">
                    <div>
                    <a href="/orders/ordersComment.php?id=' . $row['orderId'] . '">' . $row['comment'] . '</a>
                    </div>
                    <div>
                    <a href="/orders/ordersComment.php?id=' . $row['orderId'] . '">' . $row['Dt'] . '</a>
                    </div>
                    </li>

                    ';
                }
            } else {
                echo '<li class="list-group-item ">No comments today</li>';
            }

            ?>
        </ul>
    </div>


    <script src=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>