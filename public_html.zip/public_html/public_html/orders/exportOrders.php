<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body style="border: 1px solid #ccc">


    <?php  

    include "../partials/db.php";


 $query = "SELECT * FROM orders";
 $result = mysqli_query($con, $query);


  $total = 0;
  $totalQuantity = 0;
  $totalCOD = 0;
  $totalAmount = 0;
  $totalDeliveryCharge = 0;
  
     $date = date('Y-m-d');
 
  
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Sales till '.$date.'.xls');
 

?>
    <table class="table" bordered="10">
        <tr>
            <th><b>Date</b></th>
            <th><b>Name</b></th>
            <th><b>Address</b></th>
            <th><b>Contact</b></th>
            <th><b>Contact2</b></th>
            <th><b>Product</b></th>
            <th><b>Colour</b></th>
            <th><b>Quantity</b></th>
            <th><b>COD</b></th>
            <th><b>Amount</b></th>
            <th><b>Delivery Charge</b></th>
            <th><b>Message</b></th>
            <th><b>Stage</b></th>
        </tr>
        <?php
            while($row = mysqli_fetch_array($result))
  {
   echo '
    <tr>  
                         <td>'.$row["Dt"].'</td>  
                         <td>'.$row["Name"].'</td>  
                         <td>'.$row["Address"].'</td>  
                         <td>'.$row["Contact"].'</td>  
                         <td>'.$row["contact2"].'</td>
                         <td>'.$row["Product"].'</td>  
                         <td>'.$row["Colour"].'</td>  
                         <td>'.$row["Quantity"].'</td>  
                         <td>'.$row["COD"].'</td>  
                         <td>'.$row["Amount"].'</td>  
                         <td>'.$row["deliveryCharge"].'</td>  
                         <td>'.$row["Message"].'</td>  
                         <td>'.$row["Stage"].'</td>  
                    </tr>
                    
   ';
   if($row["Stage"] != 'Returned'){
   $totalQuantity += $row['Quantity'];
   $totalCOD += $row["COD"];
   $totalAmount += $row["Amount"];
   $totalDeliveryCharge += $row["deliveryCharge"];
   }


  }
        ?>

        <tr>
            <td></td>
            <td><b>Total</b></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td><b><?php echo$totalQuantity ?></b></td>
            <td><b><?php echo$totalCOD ?></b></td>
            <td><b><?php echo$totalAmount ?></b></td>
            <td><b><?php echo$totalDeliveryCharge ?></b></td>
            <td></td>
            <td></td>
        </tr>
    </table>

</body>

</html>