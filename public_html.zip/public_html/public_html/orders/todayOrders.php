<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CHASMAGHAR-Orders</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <style>
    @media (max-width: 1180px) {
        .data-table {
            overflow-x: scroll;
        }
    }

    .data-table {
        padding-top: 70px;
        padding-left: 30px;
        overflow-x: scroll;
    }

    .id {
        display: none;
    }

    .container {
        display: flex;

    }

    .select {
        /* padding-right: 180px; */
        margin-right: 20px;
    }

    a {
        text-decoration: none;
        color: black;
    }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>


    <?php
    include "../partials/db.php";
    include "../partials/header.php";
    ?>
    <div class="bg-body-secondary p-5 m-5">
        <h3 class="text-center m-5"><a href="/orders/orders.php">Filter Orders</a></h3>
        <!-- form -->
        <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" class="d-flex justify-content-evenly mt-4">
            <select class="form-select" aria-label="Default select example" name="Stage">
                <option selected disabled>Stage</option>

                <?php
                $date = date('Y-m-d');
                $sql = "SELECT DISTINCT Stage FROM orders WHERE Dt ='$date' ";
                $result = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($result)) {
                    $stage = $row['Stage'];
                    echo '<option value="' . $stage . '"  >' . $stage . '</option>';
                }
                ?>

            </select>
            <button type="submit" class="btn btn-outline-dark m-2" name="filter">Submit</button>
        </form>
    </div>

    <div class="container  text-center d-flex justify-content-between mt-5 margin-left-5">
        <form action="/orders/add_orders.php" action="POST">
            <button type="Submit" class="btn btn-success ">Add Orders</button>
        </form>
        <h2 class="pe-pd-3">Orders</h2>

        <form action="/orders/exportOrders.php" action="POST">
            <button type="Submit" class="btn btn-success ">Export to Excel</button>
        </form>
    </div>

    <div class="data-table my-3">
        <table class="table" id="myTable">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Address</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Contact2</th>
                    <th scope="col">Product</th>
                    <th scope="col">Colour</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Logistics</th>
                    <th scope="col">Pre-Payment</th>
                    <th scope="col">COD</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Message</th>
                    <th scope="col">DT</th>
                    <th scope="col">Stage</th>
                    <th scope="col">Update</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>
            <tbody>

                <?php
                if (isset($_POST['filter'])) {
                    $date = date("Y-m-d");
                    $stage = $_POST['Stage'];
                    $sn = 0;
                    $sql2 = "SELECT * FROM `orders` WHERE Stage = '$stage' AND Dt= '$date' ORDER BY id DESC";
                    $result2 = mysqli_query($con, $sql2);
                    while ($rows = mysqli_fetch_assoc($result2)) {
                        echo '
                    <tr>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . ++$sn . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Name'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Address'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Contact'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['contact2'] . '</a></td>
                    <td>' . $rows['Product'] . '</td>
                    <td>' . $rows['Colour'] . '</td>
                    <td>' . $rows['Quantity'] . '</td>
                    <td>' . $rows['deliveryCharge'] . '</td>
                    <td>' . $rows['prePayment'] . '</td>
                    <td>' . $rows['COD'] . '</td>
                    <td>' . $rows['Amount'] . '</td>
                    <td>' . $rows['Message'] . '</td>
                    <td>' . $rows['Dt'] . '</td>
                    <td>' . $rows['Stage'] . '</td>
                    <td>
                    <div class="row">';
                        $id = $rows['id'];

                        echo '
                    <form method="GET" action="/orders/update.php">
                    <div class="container">
                  
                        <select class="form-select select" name="stage" placeholder="Choose The Options">
                    <option selected  placeholder="Choose The Options" Disabled>Choose The Options</option>   
                    <option value="Order Created At NCM" >Order Created At NCM</option>
                    <option value="Packed" >Packed</option>
                     <option value="Sent for power" >Sent for power</option>
                    <option value="Dispatched" >Dispatched</option>
                    <option value="Delivered" >Delivered</option>
                    <option value="Exchange" >Exchange</option>
                    <option value="Returned" >Returned</option>
                    </select>
                    <input name="id" value="' . $id . '" class="id">
                    <input name="product" value="' . $rows['Product'] . '" class="id">
                    <input name="colour" value="' . $rows['Colour'] . '" class="id">
                    <input name="quantity" value="' . $rows['Quantity'] . '" class="id">
                    <input name="amount" value="' . $rows['Amount'] . '" class="id">
                    <input name="deliveryCharge" value="' . $rows['deliveryCharge'] . '" class="id">
                    <button type="submit" class="btn btn-outline-success" >Update</button>
                    
                    </div>
                    </form>
                   </div>
                    </td>
                    <td> <a href="/orders/deleteOrders.php?id=' . $rows['id'] . '" style="text-decoration: none; color:black;" class="text-danger "><u>Delete</u></a></td>
                </tr>';
                    }
                } else {
                    $date = date("Y-m-d");
                    $sn = 0;
                    $sql2 = "SELECT * FROM `orders` WHERE Dt = '$date' ORDER BY id DESC";
                    $result2 = mysqli_query($con, $sql2);
                    while ($rows = mysqli_fetch_assoc($result2)) {

                        echo '
                    <tr>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . ++$sn . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Name'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Address'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Contact'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['contact2'] . '</a></td>
                    <td>' . $rows['Product'] . '</td>
                    <td>' . $rows['Colour'] . '</td>
                    <td>' . $rows['Quantity'] . '</td>
                    <td>' . $rows['deliveryCharge'] . '</td>
                    <td>' . $rows['prePayment'] . '</td>
                    <td>' . $rows['COD'] . '</td>
                    <td>' . $rows['Amount'] . '</td>
                    <td>' . $rows['Message'] . '</td>
                    <td>' . $rows['Dt'] . '</td>
                    <td>' . $rows['Stage'] . '</td>
                    <td>
                    <div class="row">';
                        $id = $rows['id'];

                        echo '
                    <form method="GET" action="/orders/update.php">
                    <div class="container">
                  
                        <select class="form-select select" name="stage" placeholder="Choose The Options">
                    <option selected  placeholder="Choose The Options" Disabled>Choose The Options</option>   
                    <option value="Order Created At NCM" >Order Created At NCM</option>
                    <option value="Packed" >Packed</option>
                     <option value="Sent for power" >Sent for power</option>
                    <option value="Dispatched" >Dispatched</option>
                    <option value="Delivered" >Delivered</option>
                    <option value="Exchange" >Exchange</option>
                    <option value="Returned" >Returned</option>
                    </select>
                    <input name="id" value="' . $id . '" class="id">
                    <input name="product" value="' . $rows['Product'] . '" class="id">
                    <input name="colour" value="' . $rows['Colour'] . '" class="id">
                    <input name="quantity" value="' . $rows['Quantity'] . '" class="id">
                    <input name="amount" value="' . $rows['Amount'] . '" class="id">
                    <input name="deliveryCharge" value="' . $rows['deliveryCharge'] . '" class="id">
                    <button type="submit" class="btn btn-outline-success" >Update</button>
                    
                    </div>
                    </form>
                   </div>
                    </td>
                    <td> <a href="/orders/deleteOrders.php?id=' . $rows['id'] . '" style="text-decoration: none; color:black;" class="text-danger "><u>Delete</u></a></td>
                </tr>';
                    }
                }

                ?>



            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
    let table = new DataTable("#myTable");
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>