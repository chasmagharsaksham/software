<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Category</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="container py-5 text-center">
        <?php
        include "../partials/db.php";
        $id = $_GET['id'];
        $sql = "SELECT * from orders WHERE id = $id";
        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $name = $row['Name'];
        }
        echo '<h2>Delete '.$name.' order??</h2>';
        if(isset($_POST['confirm'])){
            if($_POST['confirm'] == 'Yes'){
                $sql2 = "DELETE FROM orders WHERE `orders`.`id` = $id";
                $result2 = mysqli_query($con, $sql2);
                if($result2){
                echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/orders/orders.php";
        </script>';
                }
            }
            else if($_POST['confirm'] == 'No'){
                echo '
        <script>
        window.location.href="https://orders-cg.000webhostapp.com/orders/orders.php";
        </script>';
            }
        }
        // include "../partials/header.php";
    ?>

    </div>

    <!-- form -->
    <div class="container  d-flex justify-content-around mb-5">
        <span class="border border-dark border-2 rounded">
            <?php
            echo '<form  method="POST"
                class="row gy-2 gx-3 align-items-center  p-5">';
                ?>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-danger px-4" name="confirm" value="Yes">Yes</button>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-success px-4" value="No" name="confirm">No</button>
            </div>
            </form>
        </span>
    </div>

    <!-- <div class="container py-5 text-center">
        <h2>Delete The Stock Also??</h2>
    </div>
    <div class="container  d-flex justify-content-around mb-5">
        <span class="border border-dark border-2 rounded">
          // <?php
          // echo '<form  method="POST"
           //     class="row gy-2 gx-3 align-items-center  p-5">';
            //    ?> 
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-danger px-4" name="confirmStock" value="Yes">Yes</button>
            </div>
            </form>
        </span>
    </div> -->
    <!-- form end -->
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
</script>

<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
    crossorigin="anonymous"></script>
<script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
let table = new DataTable("#myTable");
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</html>