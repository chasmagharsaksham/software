<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CHASMAGHAR- Monthly Report</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>


<body>


    <?php
    include "../partials/db.php";
    include "../partials/header.php";

    function sales(){
        include "../partials/db.php";
        
        $totalSales = 0;
        $sql = 'SELECT * FROM `orders` WHERE Stage NOT LIKE "Returned"';
        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $sales = $row['Amount'];
            $totalSales += $sales ;
        }

        return $totalSales;
    }

    function purchase(){
        include "../partials/db.php";
        
        $totalPurchase = 0;
        $sql = 'SELECT * FROM `purchase`';
        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $purchase = $row['amount'];
            $totalPurchase += $purchase ;
        }
        
        return $totalPurchase;
    }

    function closingStock(){
        include "../partials/db.php";
        
        $totalClosingStock = 0;
        $sql = 'SELECT * FROM `stock`';
        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $quantity = $row['quantity'];
            $cp = $row['costPrice'];

            $totalClosingStock += $quantity * $cp;
        }

        return $totalClosingStock;
    }

    function openingStock(){
        include "../partials/db.php";
        
        $openingStock = 0;
        $sql = 'SELECT * FROM `openingstock`';
        $result = mysqli_query($con, $sql);
        $num = mysqli_num_rows($result);

        while($row = mysqli_fetch_assoc($result)){
            $openingStock = $row['amount'];
        
        }
 

        return $openingStock;
    }

    function logistics(){
        include "../partials/db.php";
        
        $totalLogistics = 0;
        $sql = 'SELECT * FROM `orders`';
        $result = mysqli_query($con, $sql);

        while($row = mysqli_fetch_assoc($result)){
            $logistic = $row['deliveryCharge'];

            $totalLogistics += $logistic;
        }
        return $totalLogistics;
    }

    function miscellaneousExpenses(){
        include "../partials/db.php";
        
        $totalExpenses = 0;
        $sql = 'SELECT * FROM `miscellaneousexpenses`';
        $result = mysqli_query($con, $sql);

        while($row = mysqli_fetch_assoc($result)){
            $expenses = $row['amount'];

            $totalExpenses += $expenses;
        }
        return $totalExpenses;
    }
    function fitting(){
        include "../partials/db.php";
        
        $fitting = 0;
        $sql = 'SELECT * FROM `fitting`';
        $result = mysqli_query($con, $sql);

        while($row = mysqli_fetch_assoc($result)){
            $expenses = $row['amount'];

            $fitting += $expenses;
        }
        return $fitting;
    }

    $costOfGoodsSold = openingStock() + purchase() + fitting() - closingStock(); 
    $gross = sales() - $costOfGoodsSold;


    $otherExpenses = miscellaneousExpenses() + logistics();
    $net = $gross - $otherExpenses;
  ?>

    <div class="container  text-center d-flex justify-content-between my-5 margin-left-5">
        <p style="opacity:0;">Text</p>
        <h2 class="pe-pd-3">Monthly Report</h2>
        <form action="/accounts/exportMonthlyReport.php" method="POST">
            <button type="Submit" class="btn btn-success " href="/accounts/exportMonthlyReport.php">Export to
                Excel</button>
        </form>
    </div>

    <div class="container" style="margin-top: 10px;">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Particulars</th>
                    <th scope="col">Details</th>
                    <th scope="col">Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><b>Sales</b></td>
                    <td></td>
                    <td><b><?php $totalSales = sales(); echo $totalSales;?></b></td>
                </tr>
                <tr>

                    <td><b>Cost of Goods Sold</b></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Opening Stock</td>
                    <td><?php $amount = openingStock(); echo $amount;?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Purchase</td>
                    <td><?php $totalPurchase = purchase(); echo $totalPurchase;?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Fitting</td>
                    <td><?php $totalFitting = fitting(); echo $totalFitting;?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Colosing Stock </td>
                    <td><?php $totalClosingStock = closingStock(); echo $totalClosingStock;?></td>
                    <td><?php echo $costOfGoodsSold?></td>
                </tr>
                <tr>
                    <td><b>Gross Profit/Loss</b></td>
                    <td></td>
                    <td><b><?php echo $gross; ?></b></td>
                </tr>
                <tr>
                    <td><b>Other Expenses</b></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Logistics</td>
                    <td><?php $logistics = logistics(); echo $logistics; ?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Miscellaneous Expenses</td>
                    <td><?php $expenses= miscellaneousExpenses(); echo $expenses?></td>
                    <td></td>
                </tr>
                <tr>
                    <td><b>Net Profit/Loss</b></td>
                    <td></td>
                    <td><b><?php echo $net;?></b></td>
                </tr>
            </tbody>
        </table>
    </div>






    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</body>

</html>