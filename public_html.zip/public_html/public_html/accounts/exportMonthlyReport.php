<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body style="border: 1px solid #ccc">

    <?php
    include "../partials/db.php";


    function sales(){
        include "../partials/db.php";
        
        $totalSales = 0;
        $sql = 'SELECT * FROM `orders` WHERE Stage NOT LIKE "Returned"';
        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $sales = $row['Amount'];
            $totalSales += $sales ;
        }

        return $totalSales;
    }

    function purchase(){
        include "../partials/db.php";
        
        $totalPurchase = 0;
        $sql = 'SELECT * FROM `purchase`';
        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $purchase = $row['amount'];
            $totalPurchase += $purchase ;
        }
        
        return $totalPurchase;
    }

    function closingStock(){
        include "../partials/db.php";
        
        $totalClosingStock = 0;
        $sql = 'SELECT * FROM `stock`';
        $result = mysqli_query($con, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $quantity = $row['quantity'];
            $cp = $row['costPrice'];

            $totalClosingStock += $quantity * $cp;
        }

        return $totalClosingStock;
    }

    function openingStock(){
        include "../partials/db.php";
        
        $openingStock = 0;
        $sql = 'SELECT * FROM `openingstock`';
        $result = mysqli_query($con, $sql);
        $num = mysqli_num_rows($result);
        if($num == 1){
        while($row = mysqli_fetch_assoc($result)){
            $openingStock = $row['amount'];
        }
        }
        else{
            return "Error";
        }

        return $openingStock;
    }

    function logistics(){
        include "../partials/db.php";
        
        $totalLogistics = 0;
        $sql = 'SELECT * FROM `orders` WHERE stage NOt LIKE "Returned"';
        $result = mysqli_query($con, $sql);

        while($row = mysqli_fetch_assoc($result)){
            $logistic = $row['deliveryCharge'];

            $totalLogistics += $logistic;
        }
        return $totalLogistics;
    }

    function miscellaneousExpenses(){
        include "../partials/db.php";
        
        $totalExpenses = 0;
        $sql = 'SELECT * FROM `miscellaneousexpenses`';
        $result = mysqli_query($con, $sql);

        while($row = mysqli_fetch_assoc($result)){
            $expenses = $row['amount'];

            $totalExpenses += $expenses;
        }
        return $totalExpenses;
    }
    
    function fitting(){
        include "../partials/db.php";
        
        $fitting = 0;
        $sql = 'SELECT * FROM `fitting`';
        $result = mysqli_query($con, $sql);

        while($row = mysqli_fetch_assoc($result)){
            $expenses = $row['amount'];

            $fitting += $expenses;
        }
        return $fitting;
    }

    $costOfGoodsSold = openingStock() + purchase() + fitting() - closingStock(); 
    $gross = sales() - $costOfGoodsSold;

    
    $costOfGoodsSold = openingStock() + purchase() - closingStock(); 
    $gross = sales() - $costOfGoodsSold;

    $otherExpenses = miscellaneousExpenses() + logistics();
    $net = $gross - $otherExpenses;
    $date = date('Y-m-d');

 
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Monthly Rport till '.$date.'.xls');
  ?>


    <div class="container" style="margin-top: 10px;">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Particulars</th>
                    <th scope="col">Details</th>
                    <th scope="col">Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><b>Sales</b></td>
                    <td></td>
                    <td><b><?php $totalSales = sales(); echo $totalSales;?></b></td>
                </tr>
                <tr>

                    <td><b>Cost of Goods Sold</b></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Opening Stock</td>
                    <td><?php $totalOpeningStock = openingStock(); echo $totalOpeningStock;?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Purchase</td>
                    <td><?php $totalPurchase = purchase(); echo $totalPurchase;?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Fitting</td>
                    <td><?php $totalFitting = fitting(); echo $totalFitting;?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Colosing Stock </td>
                    <td><?php $totalClosingStock = closingStock(); echo $totalClosingStock;?></td>
                    <td><?php echo $costOfGoodsSold?></td>
                </tr>
                <tr>
                    <td><b>Gross Profit/Loss</b></td>
                    <td></td>
                    <td><b><?php echo $gross; ?></b></td>
                </tr>
                <tr>
                    <td><b>Other Expenses</b></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Logistics</td>
                    <td><?php $logistics = logistics(); echo $logistics; ?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Miscellaneous Expenses</td>
                    <td><?php $expenses= miscellaneousExpenses(); echo $expenses?></td>
                    <td></td>
                </tr>
                <tr>
                    <td><b>Net Profit/Loss</b></td>
                    <td></td>
                    <td><b><?php echo $net;?></b></td>
                </tr>
            </tbody>
        </table>
    </div>



</body>

</html>