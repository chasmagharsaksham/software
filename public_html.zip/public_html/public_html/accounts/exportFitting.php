<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body style="border: 1px solid #ccc">

    <?php
    include "../partials/db.php";


 $query = "SELECT * FROM fitting";
 $result = mysqli_query($con, $query);
  $total = 0;
  
   
    $date = date('Y-m-d');
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Miscellaneous Expenses till '.$date.'.xls');
  ?>
    <table class="table" bordered="1">
        <tr>
            <th>Date</th>
            <th>Name</th>
            <th>Amount</th>
        </tr>
        <?php
        while($row = mysqli_fetch_array($result))
  {

            $dt =    $row["dt"] ;
            $name =    $row["name"];
            $amount =    $row["amount"];
   $total += $row['amount'];
  echo'
        <tr>
            <td> '.$dt.'</td>
            <td> '.$name.'</td>
            <td> '.$amount.'</td>
        </tr>';
  }
        ?>
        <tr>
            <td></td>
            <td>Total Fitting Expense</td>
            <td><?php echo $total?></td>
        </tr>
    </table>
</body>

</html>