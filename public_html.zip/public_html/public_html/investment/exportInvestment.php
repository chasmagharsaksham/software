<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body style="border: 1px solid #ccc">



    <?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "orders");
$output = '';


 $query = "SELECT * FROM `investment`";
 $result = mysqli_query($connect, $query);

 
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th>Date</th>  
                         <th>Name</th>  
                         <th>Amount</th>  
                    </tr>
  ';
  $total = 0;
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["dt"].'</td>  
                         <td>'.$row["name"].'</td>  
                         <td>'.$row["amount"].'</td>  
                    </tr>
   ';
   $total += $row['amount'];
  }
  $output .= '
  <tr>
  <td></td>
  <td>Total Investment</td>
  <td>'.$total.'</td>
  </tr>
  </table>
  ';
  $date = date('Y-m-d');
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Miscellaneous Expenses till '.$date.'.xls');
  echo $output;
 



?>

</body>

</html>