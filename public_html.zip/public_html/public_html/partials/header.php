<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="/index.php">Chasma Ghar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/index.php">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Orders
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="/orders/orders.php">View Orders</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="/orders/add_orders.php">Add Orders</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Categories
                    </a>
                    <ul class="dropdown-menu">
                        <?php
                        if($_SERVER["SCRIPT_NAME"] == '/index.php') {
                           include "./partials/db.php";
                        }
                           else{
                                include "../partials/db.php";
                           }
                        ?>

                        <li><a class="dropdown-item" href="/category/category.php">View Category</a></li>
                        <hr class="dropdown-divider">
                        <li><a class="dropdown-item" href="/category/addCategory.php">Add Category</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Stock
                    </a>
                    <ul class="dropdown-menu">
                        <?php
                            $sql = "SELECT * from categories LIMIT 3";
                            $result = mysqli_query($con,$sql);
                            $num = mysqli_num_rows($result);
                            while($rows = mysqli_fetch_assoc($result)){
                                $name = $rows['categoryName'];
                                echo 
                                '<li><a class="dropdown-item" href="/stock/stock.php?id='.$rows['id'].'.">'.$name.'</a></li>
                                 <li>
                                    <hr class="dropdown-divider">
                                 </li>';
                                }
                                if($num >=3){
                                    echo '
                                    <li><a class="dropdown-item" href="/stock/allStock.php">View All</a></li>
                                    ';
                                }  
                        ?>
                        <hr class="dropdown-divider">
                        <li><a class="dropdown-item" href="/stock/addStock.php">Add Stock</a></li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Accounts
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="/accounts/purchase.php">Purchases</a></li>
                        <hr class="dropdown-divider">
                        <li><a class="dropdown-item" href="/accounts/fitting.php">Fitting</a></li>
                        <hr class="dropdown-divider">
                        <li><a class="dropdown-item" href="/accounts/miscellaneousExpenses.php">Miscellaneous
                                Expenses</a>
                        </li>
                        <hr class="dropdown-divider">
                        <li><a class="dropdown-item" href="/accounts/monthlyReport.php">Monthly
                                Report</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="/investment/investment.php">Investments</a>
                </li>
            </ul>

            <a class="btn btn-outline-danger" href="/resetMonth/resetMonth.php">Reset Month</a>

        </div>
    </div>
</nav>