<?php
    $server = 'localhost';
    $username = 'id21023974_root';
    $password = "Saksham@123";
    $database = "id21023974_orders";

    
    $con = mysqli_connect($server, $username, $password, $database);

    if(!$con){
        die('An error occured');
    }
?>
<html>
    <style>
        img[alt="www.000webhost.com"]{
    display: none;
}
    </style>
    <body></body>
</html>