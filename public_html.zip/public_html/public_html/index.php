<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CHASMAGHAR</title>
    <link rel="icon" type="image/x-icon" href="./img/favicon-32x32.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <style>
    @media (max-width: 1180px) {
        .data-table {
            overflow-x: scroll;
        }

        .select {

            padding-right: 180px !important;
        }
    }

    .data-table {
        padding: 55px;
    }

    .id {
        display: none;
    }

    .container {
        display: flex;

    }

    .select {
        padding-right: 0px;
        margin-right: 20px;
    }

    .first {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    img{
            /*height: 150px;*/
            width: 130px;
            aspect-ratio: 3/2
            object-fit: contain;
            /*mix-blend-mode: color-burn;*/
            transition: .4s ease;
            border-radius: 10px;
            margin: 20px 0px;
        }
        
        img:hover{
            filter: drop-shadow(0 0 10px #999);
            width: 140px;
            margin: 12px 0px;
            
        }

    .data-table {
        padding-top: 70px;
        padding-left: 30px;

    }

    .id {
        display: none;
    }

    .container {
        display: flex;

    }

    .select {
        /* padding-right: 180px; */
        margin-right: 20px;
    }

    a {
        text-decoration: none;
        color: black;
    }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>

    <?php
    include "./partials/db.php";
    include "./partials/header.php";

    //Total categorized orders
    function orders($stage)
    {
        $sql = "SELECT * FROM `orders` WHERE `Stage` = '" . $stage . "'";
        $result = mysqli_query($GLOBALS['con'], $sql);
        $num = mysqli_num_rows($result);
        echo $num;
    }

    function pendingOrders()
    {
        $sql = "SELECT * FROM `orders` WHERE `Stage` NOT LIKE 'Delivered' AND Stage NOT LIKE 'Returned'";
        $result = mysqli_query($GLOBALS['con'], $sql);
        $num = mysqli_num_rows($result);
        echo $num;
    }


    $sql_amount_query = 'SELECT SUM(Amount) FROM orders  WHERE Stage NOT LIKE "Returned"';
    $sql_amount = mysqli_query($GLOBALS['con'], $sql_amount_query);
    while ($rows =  mysqli_fetch_assoc($sql_amount)) {
        $total =  $rows['SUM(Amount)'];
    }


    function miscellaneousExpenses()
    {

        $totalExpenses = 0;
        $sql = 'SELECT * FROM `miscellaneousexpenses`';
        $result = mysqli_query($GLOBALS['con'], $sql);

        while ($row = mysqli_fetch_assoc($result)) {
            $expenses = $row['amount'];

            $totalExpenses += $expenses;
        }
        return $totalExpenses;
    }

    function purchase()
    {


        $totalPurchase = 0;
        $sql = 'SELECT * FROM `purchase`';
        $result = mysqli_query($GLOBALS['con'], $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            $purchase = $row['amount'];
            $totalPurchase += $purchase;
        }

        return $totalPurchase;
    }

    $totalExpenses = purchase() + miscellaneousExpenses();

    $totalInvestment = 0;
    $sql = 'SELECT * FROM `investment`';
    $result = mysqli_query($GLOBALS['con'], $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $investment = $row['amount'];
        $totalInvestment += $investment;
    }

    function numToday($database)
    {
        $n = 0;
        $sql = "SELECT * from $database";
        $result = mysqli_query($GLOBALS["con"], $sql);
        foreach ($result as  $row) {
            $date = $row['Dt'];
            if ($date == date("Y-m-d")) {
                $n++;
            }
        }
        echo $n;
    }

    ?>
    <!-- todays report -->
    <div class="amounts mt-5">
        <h1 class="text-center my-6">
            <?php
            echo date("Y-d-m");
            ?>
        </h1>
        <div class="container my-5 first">
            <div class="row">
                <div class="card mx-4" style="width: 18rem ">
                    <a href="/orders/todayOrders.php">
                        <div class="card-body">
                            <h5 class="card-title text-center fs-5 text">
                                Total Orders
                            </h5>
                            <p class="card-text my-3 text-center fs-5 text">
                                <?php numToday('orders'); ?>
                            </p>
                        </div>
                    </a>
                </div>
                <div class="card mx-4" style="width: 18rem">
                    <a href="/orders/allComment.php">
                        <div class="card-body">
                            <h5 class="card-title text-center fs-5 text">
                                Total Comments
                            </h5>
                            <p class="card-text my-3 text-center fs-5 text">
                                <?php numToday('comments'); ?>
                            </p>
                        </div>
                    </a>
                </div>
                <div class="card mx-4" style="width: 18rem">
                    <div class="card-body">
                        <h5 class="card-title text-center fs-5 text">
                            Total Sales
                        </h5>
                        <p class="card-text my-3 text-center fs-5 text">
                            <?php
                            $todayAmount = 0;
                            $sql = "SELECT * from orders WHERE Stage NOT LIKE 'Returned'";
                            $result = mysqli_query($GLOBALS["con"], $sql);
                            foreach ($result as $row) {
                                if ($row["Dt"] == date("Y-m-d")) {
                                    $todayAmount += $row["Amount"];
                                }
                            }
                            echo $todayAmount;
                            ?>
                        </p>
                    </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Orders -->
    <div class="orders">
        <h1 class="text-center my-4">
            Orders
        </h1>
        <div class="container my-5 first">
            <div class="row center">
                <div class="card mx-4" style="width: 18rem">
                    <div class="card-body">
                        <h5 class="card-title text-center fs-5 text">Delivered Orders</h5>
                        <p class="card-text my-3 text-center fs-5 text">
                            <?php
                            orders("Delivered");
                            ?>
                        </p>
                    </div>
                </div>

                <div class="card mx-4" style="width: 18rem">
                    <div class="card-body">
                        <h5 class="card-title text-center fs-5 text"> Pending Orders</h5>
                        <p class="card-text my-3 text-center fs-5 text">
                            <?php
                            pendingOrders();
                            ?>
                        </p>
                    </div>
                </div>

                <div class="card mx-4" style="width: 18rem">
                    <div class="card-body">
                        <h5 class="card-title text-center fs-5 text">Returned Orders</h5>
                        <p class="card-text my-3 text-center fs-5 text">
                            <?php
                            orders("Returned");
                            ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Amounts -->
    <div class="amounts">
        <h1 class="text-center my-6">
            Amounts
        </h1>
        <div class="container my-5 first">
            <div class="row">
                <div class="card mx-4" style="width: 18rem ">
                    <div class="card-body">
                        <h5 class="card-title text-center fs-5 text">
                            Total Sales
                        </h5>
                        <p class="card-text my-3 text-center fs-5 text">
                            <?php
                            if ($total <= 0) {
                                echo 0;
                            } else {
                                echo $total;
                            }

                            ?>
                        </p>
                    </div>
                </div>
                <div class="card mx-4" style="width: 18rem">
                    <div class="card-body">
                        <h5 class="card-title text-center fs-5 text">
                            Total Expenses
                        </h5>
                        <p class="card-text my-3 text-center fs-5 text">
                            <?php

                            if ($totalExpenses <= 0) {
                                echo 0;
                            } else {

                                echo $totalExpenses;
                            }
                            ?>
                        </p>
                    </div>
                </div>
                <div class="card mx-4" style="width: 18rem">
                    <div class="card-body">
                        <h5 class="card-title text-center fs-5 text">
                            Total Investments
                        </h5>
                        <p class="card-text my-3 text-center fs-5 text">
                            <?php

                            if ($totalInvestment <= 0) {
                                echo 0;
                            } else {

                                echo $totalInvestment;
                            }
                            ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <hr class="border border-dark border-2 opacity-100">
    <h1 class="text-center my-4 mt-5">
        Pending Orders
    </h1>

    <div class="data-table my-3">
        <table class="table" id="myTable">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Address</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Stage</th>
                    <th scope="col">Update</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM `orders` WHERE stage NOT LIKE 'Delivered' AND stage NOT LIKE 'Returned' ORDER BY id DESC";
                $result = mysqli_query($con, $sql);
                $sn = 0;
                while ($rows = mysqli_fetch_assoc($result)) {
                    echo '
                    <tr>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . ++$sn . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Name'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Address'] . '</a></td>
                    <td><a href="/orders/ordersComment.php?id=' . $rows['id'] . '">' . $rows['Contact'] . '</a></td>
                    <td>' . $rows['Amount'] . '</td>
                    <td>' . $rows['Stage'] . '</td>
                    <td>
                    <div class="row">';
                    $id = $rows['id'];

                    echo '
                    <form method="GET" action="/orders/update2.php">
                    <div class="container">
                  
                        <select class="form-select select" name="stage" placeholder="Choose The Options">
                    <option selected  placeholder="Choose The Options" Disabled>Choose The Options</option>   
                    <option value="Order Created At NCM" >Order Created At NCM</option>
                    <option value="Packed" >Packed</option>
                     <option value="Sent for power" >Sent for power</option>
                    <option value="Dispatched" >Dispatched</option>
                    <option value="Delivered" >Delivered</option>
                    <option value="Returned" >Returned</option>
                    </select>
                    <input name="id" value="' . $id . '" class="id">
                    <input name="product" value="' . $rows['Product'] . '" class="id">
                    <input name="colour" value="' . $rows['Colour'] . '" class="id">
                    <input name="quantity" value="' . $rows['Quantity'] . '" class="id">
                    <button type="submit" class="btn btn-outline-success" >Update</button>
                    
                    </div>
                    </form>
                   </div>
                    </td>
                </tr>';
                }


                ?>

            </tbody>
        </table>
    </div>
    <hr class="border border-dark border-2 opacity-100">
    <div class="container-2">
        <h1 class="text-center my-4 mt-5">
            Low Stocks
        </h1>

        <div class="data-table p-5">
            <table class="table" id="myTable2">
                <thead>
                    <tr>
                        <th scope="col">S.N</th>
                        <th scope="col">Model</th>
                        <th scope="col">Name</th>
                        <th scope="col">Colour</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sn = 0;
                    $sql2 = "SELECT * FROM `stock` WHERE quantity < 1";
                    $result2 = mysqli_query($con, $sql2);
                    while ($row2 = mysqli_fetch_assoc($result2)) {
                        echo '
                                <tr>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . ++$sn . '</a></td>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . $row2['modelNumber'] . '</a></td>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . $row2['modelName'] . '</a></td>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . $row2['colour'] . '</a></td>
                                <td>' . $row2['quantity'] . '</td>
                                <td><img src="./Images/' . $row2['img'] . '" class="image" alt="' . $row2['modelName'] . '"></td>
                                </tr>
                            ';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
    let table = new DataTable("#myTable");
    </script>

    <script>
    let table2 = new DataTable("#myTable2");
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>