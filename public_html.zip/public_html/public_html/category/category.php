<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CHASMAGHAR-Category</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>


<body>


    <?php
    include "../partials/db.php";
    include "../partials/header.php";
    ?>
    <div class="container text-center py-5">
        <h2> Categories</h2>
    </div>
    <div class="container  d-flex justify-content-around mb-5">
        <span class="border border-dark border-2 rounded">
            <ul class="list-group list-group-numbered p-5 ">
                <?php
                $sn = 1;
            $sql = "SELECT * from categories";
            $result = mysqli_query($con, $sql);
            while($row = mysqli_fetch_assoc($result)){
               echo' 
                <li class="list-group-item pt-2   d-flex justify-content-around mb-5">
               <b><a href="/stock/stock.php?id='.$row['id'].'" style="text-decoration: none; color:black;"> '.$row['categoryName'].'</a></b> <a class="px-4 text-danger" href="/category/deleteCategory.php?id='.$row['id'].'">Delete</a>
                </li>';
            }
        ?>
            </ul>
        </span>
    </div>

    </tbody>
    </table>
    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
    let table = new DataTable("#myTable");
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>

</html>