<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CHASMAGHAR-Add Category</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>


<body>


    <?php
    include "../partials/db.php";
    include "../partials/header.php";
    

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $name = $_POST['categoryName'];

        
        $sql = "INSERT INTO `categories` (`categoryName`,`dt`) VALUES ('$name', current_timestamp())";
        $result = mysqli_query($con, $sql);
        if($result){
             echo 
              "
    <script>
    Swal.fire(

        'Addedd Successfully',
        'Added <b>".$name."</b> to categories successfully!!',
        'success'
    )
    </script>";
        }
        }

        
        
    
?>

    <div class="container py-5 text-center"">
            <h2>Add Categories</h2>
        </div>

        <!-- form -->
        <div class=" container d-flex justify-content-around mb-5">
        <span class="border border-dark border-2 rounded">
            <form action=" /category/addCategory.php" method="POST" class="row gy-2 gx-3 align-items-center  p-5">

                <div class="col-auto">
                    <label class="visually-hidden" for="autoSizingInput">Name</label>
                    <input type="text" class="form-control" id="categoryName" placeholder="Category Name"
                        name="categoryName" required>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-outline-dark">Submit</button>
                </div>
            </form>
        </span>
    </div>

    <!-- form end -->
    <hr class="border border-dark border-2 opacity-100">






    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
    let table = new DataTable("#myTable");
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>

</html>