<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body style="border: 1px solid #ccc">

    <?php
    include "../partials/db.php";


 $query = "SELECT * FROM stock";
 $result = mysqli_query($con, $query);
  $total = 0;
  
   
    $date = date('Y-m-d');
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Stock till '.$date.'.xls');
  ?>
    <table class="table" bordered="1">
        <tr>
            <th>Model Number</th>
            <th>Model Name</th>
            <th>Colour</th>
            <th>Quantity</th>
            <th>Box Number</th>
            <th>Cost Price</th>
            <th>Selling Price</th>
            <th>Image</th>
        </tr>
        <?php
        while($row = mysqli_fetch_array($result))
  {

            $modelNumber =    $row["modelNumber"] ;
            $name =    $row["modelName"];
            $quantity =    $row["quantity"];
            $colour =    $row["colour"] ;
            $boxNumber =    $row["boxNumber"];
            $sp =    $row["sellingPrice"];
            $cp =    $row["costPrice"];
   $totalQuantity += $row['quantity'];
   $totalCp += $row['costPrice'];
   $totalSp += $row['sellingPrice'];
  echo'
        <tr>
            <td> '.$modelNumber.'</td>
            <td> '.$name.'</td>
            <td> '.$colour.'</td>
            <td> '.$quantity.'</td>
            <td> '.$boxNumber.'</td>
            <td> '.$cp.'</td>
            <td> '.$sp.'</td>
        </tr>';
  }
        ?>
        <tr>
            <td></td>
            <td>Total</td>
            <td></td>
            <td><?php echo $totalQuantity?></td>
            <td></td>
            <td><?php echo $totalCp?></td>
            <td><?php echo $totalSp?></td>

        </tr>
    </table>
</body>

</html>