<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CHASMAGHAR-STOCK</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
     @media (max-width: 1180px) {
        .data-table {
            overflow-x: scroll;
        }
    }
        img{
            /*height: 150px;*/
            width: 130px;
            aspect-ratio: 3/2
            object-fit: contain;
            /*mix-blend-mode: color-burn;*/
            transition: .4s ease;
            border-radius: 10px;
            margin: 20px 0px;
        }
        
        img:hover{
            filter: drop-shadow(0 0 10px #999);
            width: 140px;
            margin: 12px 0px;
            
        }

        a {
            text-decoration: none;
            color: black;
        }
    </style>
</head>

<body>
    <?php
    include "../partials/db.php";
    include "../partials/header.php";


    ?>
    <div class="bg-body-secondary p-5 m-5">
        <h3 class="text-center m-5"><a href="/stock/allStock.php">Filter Stock - Clear Filter</a></h3>
        <!-- form -->
        <form action=" /stock/allStock.php" method="POST" class="d-flex justify-content-evenly mt-4">
            <select class="form-select" aria-label="Default select example" name="number2">
                <option selected disabled>Box Number</option>

                <?php
                $sql = "SELECT DISTINCT boxNumber FROM stock";
                $result = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($result)) {
                    $number2 = $row['boxNumber'];
                    echo '<option value="' . $number2 . '" >' . $number2 . '</option>';
                }
                ?>

            </select>
            <button type="submit" class="btn btn-outline-dark m-2" name="filter">Submit</button>
        </form>
    </div>
    <!-- form end -->


    <div class="container  text-center d-flex justify-content-between mt-5 margin-left-5">
        <p style="opacity:0;">Text</p>
        <h2 class="pe-pd-3">Stock</h2>

        <form action="/stock/exportStock.php" action="POST">
            <button type="Submit" class="btn btn-success ">Export to Excel</button>
        </form>
    </div>

    <div class="data-table p-5">
        <table class="table" id="myTable">
            <thead>
                <tr>
                    <th scope="col">S.N</th>
                    <th scope="col">Model Number</th>
                    <th scope="col">Name</th>
                    <th scope="col">Colour</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Box Number</th>
                    <th scope="col">Cost Price</th>
                    <th scope="col">Selling Price</th>
                    <th scope="col">Image</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($_POST['filter'])) {
                    $number2 = $_POST['number2'];
                    $sn = 0;
                    $sql2 = "SELECT * FROM `stock` WHERE boxNumber = '$number2' ORDER BY id DESC";
                    $result2 = mysqli_query($con, $sql2);
                    while ($row2 = mysqli_fetch_assoc($result2)) {
                        echo '
                                <tr>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . ++$sn . '</a></td>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . $row2['modelNumber'] . '</a></td>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . $row2['modelName'] . '</a></td>
                                <td>' . $row2['colour'] . '</td>
                                <td>' . $row2['quantity'] . '</td>
                                <td>' . $row2['boxNumber'] . '</td>
                                <td>' . $row2['costPrice'] . '</td>
                                <td>' . $row2['sellingPrice'] . '</td>
                                <td><img src="../Images/' . $row2['img'] . '" class="image" alt="' . $row2['modelName'] . '"></td>
                                </tr>
                            ';
                    }
                } else {

                    $sn = 0;
                    $sql2 = "SELECT * FROM `stock` ORDER BY id DESC";
                    $result2 = mysqli_query($con, $sql2);
                    while ($row2 = mysqli_fetch_assoc($result2)) {
                        echo '
                                <tr>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . ++$sn . '</a></td>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . $row2['modelNumber'] . '</a></td>
                                <td><a href="/stock/editStock.php?id=' . $row2['id'] . '">' . $row2['modelName'] . '</a></td>
                                <td>' . $row2['colour'] . '</td>
                                <td>' . $row2['quantity'] . '</td>
                                <td>' . $row2['boxNumber'] . '</td>
                                <td>' . $row2['costPrice'] . '</td>
                                <td>' . $row2['sellingPrice'] . '</td>
                                 <td><img src="../Images/' . $row2['img'] . '" class="image" alt="' . $row2['modelName'] . '"></td>
                                </tr>
                            ';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
        let table = new DataTable("#myTable");
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>

</html>