<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CHASMAGHAR-STOCK</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
    .image {
        height: 100px;
        width: 100px;
    }


    .hidden {
        display: none;
    }

    a {
        text-decoration: none;
        color: black;
    }
    </style>
</head>

<body>

    <?php
    include "../partials/db.php";
    include "../partials/header.php";
    $id = $_GET['id'];
    $sql = "SELECT * FROM `stock` WHERE id = $id";
    $result = mysqli_query($con, $sql);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $model = $row['modelNumber'];
            $name = $row['modelName'];
            $colours = $row['colour'];
            $quantitys = $row['quantity'];
            $boxNumbers = $row['boxNumber'];
            $cps = $row['costPrice'];
            $sps = $row['sellingPrice'];
            $categories = $row['category'];
            $img = $row['img'];
        }
    }


    if (isset($_POST['submit'])) {
        $modelNumber = $_POST['modelNumber'];
        $modelName = trim(strtolower($_POST['modelName']));
        $colour = trim(strtolower($_POST['colour']));
        $quantity = $_POST['quantity'];
        $boxNumber = $_POST['boxNumber'];
        $costPrice = $_POST['costPrice'];
        $sellingPrice = $_POST['sellingPrice'];

        $filename = $_FILES['image']['name'];
        $filesize = $_FILES['image']['size'];
        $filetmp = $_FILES['image']['tmp_name'];
        $filetype = $_FILES['image']['type'];
        $folder = '../Images/' . $filename;

        if ($_FILES["image"]["size"] > 0) {

            $sql2 = "UPDATE `stock` SET `modelNumber` = '$modelNumber', `modelName` = '$modelName', `colour` = '$colour',  `boxNumber` = '$boxNumber',`quantity` = '$quantity', `costPrice` = '$costPrice', `sellingPrice` = '$sellingPrice', `img` = '$filename' WHERE `stock`.`id` = $id";
            $result2 = mysqli_query($con, $sql2);
            if ($result2 && move_uploaded_file($filetmp, $folder)) {
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong> Success!!</strong> Product updated with image successfully.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>   ';
            } else {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong> Error!!</strong> Sorry an error occured.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>   ';
            }
        } else {
            $sql2 = "UPDATE `stock` SET `modelNumber` = '$modelNumber', `modelName` = '$modelName', `colour` = '$colour',  `boxNumber` = '$boxNumber',`quantity` = '$quantity', `costPrice` = '$costPrice', `sellingPrice` = '$sellingPrice' WHERE `stock`.`id` = $id";
            $result2 = mysqli_query($con, $sql2);
            if ($result2) {
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong> Success!!</strong> Product updated successfully.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>   ';
            } else {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong> Error!!</strong> Sorry an error occured.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>   ';
            }
        }
    }




    echo '
        <div class="container pt-5 text-center d-flex justify-content-center">
        <h2 class="py-4"><a href="/stock/allStock.php">' . $name . '</a></h2>
        </div>
        ';
    ?>

    <!-- form -->
    <div class=" container py-5">
        <form action="/stock/editStock.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Model Number</label>
                <input type="text" class="form-control" id="model" aria-describedby="emailHelp" name="modelNumber"
                    value="<?php echo $model; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input type="text" class="form-control" id="model" aria-describedby="emailHelp" name="modelName"
                    value="<?php echo $name; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Colour</label>
                <input type="text" class="form-control" id="colour" aria-describedby="emailHelp" name="colour"
                    value="<?php echo $colours; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Quantity</label>
                <input type="number" class="form-control" id="quantity" aria-describedby="emailHelp" name="quantity"
                    value="<?php echo $quantitys; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Box Number</label>
                <input type="text" class="form-control" id="quantity" aria-describedby="emailHelp" name="boxNumber"
                    value="<?php echo $boxNumbers; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Cost Price</label>
                <input type="number" class="form-control" id="costPrice" name="costPrice" value="<?php echo $cps; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Selling Price</label>
                <input type="number" class="form-control" id="sellingPrice" name="sellingPrice"
                    value="<?php echo $sps; ?>" />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Category</label>
                <input type="text" class="form-control" id="sellingPrice" name="category"
                    value="<?php echo $categories; ?>" disabled />
            </div>
            <div class="mb-3">
                <input type="file" name="image"accept="image/*" class="form-control" />
            </div>
            <button type="submit" class="btn btn-outline-primary my-2" name="submit">Submit</button>
        </form>
    </div>
    <!-- form end -->



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
    let table = new DataTable("#myTable");
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>

</html