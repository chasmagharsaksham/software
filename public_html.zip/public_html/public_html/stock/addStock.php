<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CHASMAGHAR-Add Stock</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon-32x32.png" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <?php
    include "../partials/db.php";
    include "../partials/header.php";
    // Post Request For Adding Stock
    if (isset($_POST['model'])) {

        //Taking Data from form
        $model = trim(strtolower($_POST['model']));
        $name = trim($_POST['name']);
        $colour = trim(strtolower($_POST['colour']));
        $boxNumber = trim($_POST['boxNumber']);
        $quantity = trim($_POST['quantity']);
        $costPrice = trim($_POST['costPrice']);
        $sellingPrice = trim($_POST['sellingPrice']);
        $category = trim($_POST['category']);
        $filename = $_FILES['image']['name'];
        $filesize = $_FILES['image']['size'];
        $filetmp = $_FILES['image']['tmp_name'];
        $filetype = $_FILES['image']['type'];
        $folder = '../Images/' . $filename;

        //Sql to check if the item is on stock or not
        $sql = "SELECT * from `stock` WHERE modelName = '$name' AND colour = '$colour'";
        $result = mysqli_query($con, $sql);
        $num = mysqli_num_rows($result);
        if ($num >= 1) {
            echo '
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong> Error!!</strong> Product is already in stock.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>        
            ';
        } else {

            if ($_FILES["image"]["size"] > 0) {

                //Sql to add the stock to database

                $sql = "INSERT INTO `stock` (`modelNumber`,`modelName`, `colour`, `boxNumber`, `quantity`, `costPrice`, `sellingPrice`, `category`, `img`, `dt`) VALUES ('$model','$name', '$colour', '$boxNumber', '$quantity', '$costPrice', '$sellingPrice', '$category', '$filename', current_timestamp())";
                $result = mysqli_query($con, $sql);
                if ($result && move_uploaded_file($filetmp, $folder)) {
                    echo '
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong> Success!!</strong> Product added in stock.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
                } else {
                    echo '
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong> Error!!</strong> Sorry, Something Went wrong.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
                }
            } else {
                $sql = "INSERT INTO `stock` (`modelNumber`,`modelName`, `colour`, `boxNumber`, `quantity`, `costPrice`, `sellingPrice`, `category`,  `dt`) VALUES ('$model','$name', '$colour', '$boxNumber', '$quantity', '$costPrice', '$sellingPrice', '$category', current_timestamp())";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    echo '
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong> Success!!</strong> Product added in stock.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
                } else {
                    echo '
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong> Error!!</strong> Sorry, Something Went wrong.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
                }
            }
        }
    }
    ?>

    <div class="container pt-5 text-center">
        <h2>Add Stock</h2>
    </div>

    <!-- form -->
    <div class=" container py-5">
        <form action="/stock/addStock.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Model Number</label>
                <input type="text" class="form-control" id="model" aria-describedby="emailHelp" name="model" />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input type="text" class="form-control" id="model" aria-describedby="emailHelp" name="name" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Colour</label>
                <input type="text" class="form-control" id="colour" aria-describedby="emailHelp" name="colour" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Quantity</label>
                <input type="number" class="form-control" id="quantity" aria-describedby="emailHelp" name="quantity" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Box Number</label>
                <input type="text" class="form-control" id="boxNumber" aria-describedby="emailHelp" name="boxNumber" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Cost Price</label>
                <input type="number" class="form-control" id="costPrice" name="costPrice" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Selling Price</label>
                <input type="number" class="form-control" id="sellingPrice" name="sellingPrice" required />
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label"> Category</label>
                <select class="form-select select" name="category" placeholder="Choose The Options" required>
                    <option selected placeholder="Choose The Options" Disabled>Choose The Options</option>
                    <?php
                    //sql to fetch category from database
                    $sql = "SELECT * from categories";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '
                                <option value="' . $row['categoryName'] . '" required>' . $row['categoryName'] . '</option>
                            ';
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Image</label>
                <input type="file" class="form-control" id="imageLink" name="image" placeholder="Image Address" accept="image/*" />
            </div>
            <button type="submit" class="btn btn-outline-primary my-2">Submit</button>
        </form>
    </div>
    <!-- form end -->




    <script src=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
        let table = new DataTable("#myTable");
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>

</html>